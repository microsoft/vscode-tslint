#!/usr/bin/python -B

import sys
import argparse
import subprocess
from netaddr import *

parser = argparse.ArgumentParser(description='Checks overlap of networks and returns conflict-free subnets.')
parser.add_argument("network_tested", help="Network to be tested.")
parser.add_argument("networks_base", help="Networks (comma separated) to be tested against.")
parser.add_argument('--conflicting', action='store_true', help='Return the conflicting subnets instead of the sliced subnets')
args = parser.parse_args()

# get requested target address
networkBaseStringList = args.networks_base.split(",")
networkTested = IPSet([args.network_tested])

# check if we have a conflict
for networkBaseString in networkBaseStringList:
    networkBase = IPNetwork(networkBaseString);
        
    if networkBase in networkTested:
      # print("Excluding network " + str(networkBase) + " from tested network " + str(networkTested));
      networkTested.remove(networkBase)

if args.conflicting:
  networkTested = IPSet([args.network_tested]) - networkTested

# return our final set of routes
if len(networkTested) >= 1:
  networkStringlist = ' '.join(str(x) for x in list(networkTested.iter_cidrs()));
  print(networkStringlist)