#!/bin/bash -e
# Note: must be bash; uses bash-specific tricks
#
# ******************************************************************************************************************
# This OpenVPN script does everything! It handles TUN and TAP interfaces,
# pushed configurations and DHCP leases. :)
#
# This is the "Down" version of the script, executed after the connection is
# closed.
#
# Created by: Nick Williams (using original code and parts of old Tblk scripts)
# Modified by: Fabian Jaeger for Shimo
#
# ******************************************************************************************************************

# @param String message - The message to log
logMessage()
{
    echo "$(date '+%Y-%m-%d %T') *Shimo: "${@} >> "${SCRIPT_LOG_FILE}"
}

# @param String message - The message to log
logDebugMessage()
{
    echo "$(date '+%Y-%m-%d %T') *Shimo: "${@} >> "${SCRIPT_LOG_FILE}"
}

# @param String string - Content to trim
trim()
{
    echo ${@}
}

# @param String list - list of network service names, output from disable_ipv6()
restore_ipv6() {

    # Undoes the actions performed by the disable_ipv6() routine in openvpn-up.sh by restoring the IPv6
    # 'automatic' setting for each network service for which that routine disabled IPv6.
    #
    # $1 must contain the output from disable_ipv6() -- the list of network services.
    #
    # This routine outputs log messages describing its activities.

    if [ "$1" = "" ] ; then
        return
    fi

    printf %s "$1
" | \
    while IFS= read -r ripv6_service ; do
        networksetup -setv6automatic "$ripv6_service"
        logMessage "Re-enabled IPv6 (automatic) for '$ripv6_service'"
    done
}

##########################################################################################
flushDNSCache()
{
    if ${ARG_FLUSH_DNS_CACHE} ; then
        if [ -f /usr/bin/dscacheutil ] ; then
            set +e # we will catch errors from dscacheutil
            /usr/bin/dscacheutil -flushcache
            if [ $? != 0 ] ; then
					logMessage "WARNING: Unable to flush the DNS cache via dscacheutil"
            else
                logMessage "Flushed the DNS cache via dscacheutil"
            fi
            set -e # bash should again fail on errors
        else
				logMessage "WARNING: /usr/bin/dscacheutil not present. Not flushing the DNS cache via dscacheutil"
        fi
        
        if [ -f /usr/sbin/discoveryutil ] ; then
            set +e # we will catch errors from discoveryutil
            /usr/sbin/discoveryutil udnsflushcaches
            if [ $? != 0 ] ; then
					logMessage "WARNING: Unable to flush the DNS cache via discoveryutil udnsflushcaches"
            else
                logMessage "Flushed the DNS cache via discoveryutil udnsflushcaches"
            fi
            /usr/sbin/discoveryutil mdnsflushcache
            if [ $? != 0 ] ; then
					logMessage "WARNING: Unable to flush the DNS cache via discoveryutil mdnsflushcache"
            else
                logMessage "Flushed the DNS cache via discoveryutil mdnsflushcache"
            fi
            set -e # bash should again fail on errors
        else
            logMessage "/usr/sbin/discoveryutil not present. Not flushing the DNS cache via discoveryutil"
        fi
            
        set +e # "grep" will return error status (1) if no matches are found, so don't fail on individual errors
        hands_off_ps="$( ps -ax | grep HandsOffDaemon | grep -v grep.HandsOffDaemon )"
        set -e # We instruct bash that it CAN again fail on errors
        if [ "${hands_off_ps}" = "" ] ; then
            if [ -f /usr/bin/killall ] ; then
                set +e # ignore errors if mDNSResponder isn't currently running
                /usr/bin/killall -HUP mDNSResponder
                if [ $? != 0 ] ; then
                    logMessage "mDNSResponder not running. Not notifying it that the DNS cache was flushed"
                else
                    logMessage "Notified mDNSResponder that the DNS cache was flushed"
                fi
                set -e # bash should again fail on errors
            else
					logMessage "WARNING: /usr/bin/killall not present. Not notifying mDNSResponder that the DNS cache was flushed"
            fi
        else
				logMessage "WARNING: Hands Off is running.  Not notifying mDNSResponder that the DNS cache was flushed"
        fi
    fi
}

##########################################################################################
resetPrimaryInterface()
{
    set +e # "grep" will return error status (1) if no matches are found, so don't fail on individual errors
    WIFI_INTERFACE="$(networksetup -listallhardwareports | awk '$3=="Wi-Fi" {getline; print $2}')"
    if [ "${WIFI_INTERFACE}" == "" ] ; then
        WIFI_INTERFACE="$(networksetup -listallhardwareports | awk '$3=="AirPort" {getline; print $2}')"
    fi
    PINTERFACE="$( scutil <<-EOF |
    open
    show State:/Network/Global/IPv4
    quit
EOF
    grep PrimaryInterface | sed -e 's/.*PrimaryInterface : //'
    )"
    set -e # resume abort on error

    if [ "${PINTERFACE}" != "" ] ; then
        if [ "${PINTERFACE}" == "${WIFI_INTERFACE}" -a -f /usr/sbin/networksetup ] ; then
            logMessage "Resetting primary interface '${PINTERFACE}' via networksetup -setairportpower ${PINTERFACE} off/on..."
            /usr/sbin/networksetup -setairportpower "${PINTERFACE}" off
            sleep 2
            /usr/sbin/networksetup -setairportpower "${PINTERFACE}" on
        else
            if [ -f /sbin/ifconfig ] ; then
                logMessage "Resetting primary interface '${PINTERFACE}' via ifconfig ${PINTERFACE} down/up..."
                /sbin/ifconfig "${PINTERFACE}" down
                sleep 2
                /sbin/ifconfig "${PINTERFACE}" up
            else
				logMessage "WARNING: Not resetting primary interface because /sbin/ifconfig does not exist."
            fi
        fi
    else
        logMessage "WARNING: Not resetting primary interface because it cannot be found."
    fi
}

##########################################################################################
trap "" TSTP
trap "" HUP
trap "" INT
export PATH="/bin:/sbin:/usr/sbin:/usr/bin"

readonly OUR_NAME=$(basename "${0}")
readonly SCRIPT_FILE=$0
readonly SCRIPT_LOG_FILE="${SCRIPT_FILE%%.*}.log"

# set Shimo defaults, if not already set before
if [ -z ${SHIMO_USE_REMOTE_DNS} ]; then
    SHIMO_USE_REMOTE_DNS="false"
fi
if [ -z ${SHIMO_USE_REMOTE_DNS_FOR_DOMAINS_ONLY} ]; then
    SHIMO_USE_REMOTE_DNS_FOR_DOMAINS_ONLY="false"
fi

readonly SHIMO_USE_REMOTE_DNS
readonly SHIMO_USE_REMOTE_DNS_FOR_DOMAINS_ONLY

logMessage "**********************************************"
logMessage "Start of output from ${OUR_NAME}"

# Remove the flag file that indicates we need to run the down script

if [ -e "/tmp/shimo-downscript-needs-to-be-run.txt" ] ; then
    rm -f "/tmp/shimo-downscript-needs-to-be-run.txt"
else
    logMessage "No need to run the down script. Stopping here."
    logMessage "**********************************************"
    exit 0
fi

# Test for the "-r" Shimo option (Reset primary interface after disconnecting) because we _always_ need its value.
# Usually we get the value for that option (and the other options) from State:/Network/OpenVPN,
# but that key may not exist (because, for example, there were no DNS changes).
# So we get the value from the Shimo options passed to this script by OpenVPN.
#
# We do the same thing for the -f Shimo option (Flush DNS cache after connecting or disconnecting)
ARG_RESET_PRIMARY_INTERFACE_ON_DISCONNECT="false"
ARG_FLUSH_DNS_CACHE="false"
while [ {$#} ] ; do
    if [ "${1:0:1}" != "-" ] ; then             # Shimo arguments start with "-" and come first
        break                                   # so if this one doesn't start with "-" we are done processing Shimo arguments
    fi
    if [ "$1" = "-r" ] ; then
        ARG_RESET_PRIMARY_INTERFACE_ON_DISCONNECT="true"
    elif [ "$1" = "-f" ] ; then
        ARG_FLUSH_DNS_CACHE="true"
    fi
    shift                                       # Shift arguments to examine the next option (if there is one)
done

# Quick check - is the configuration there?
if ! scutil -w State:/Network/OpenVPN &>/dev/null -t 1 ; then
    # Configuration isn't there
    logMessage "WARNING: Not restoring DNS settings because no saved Shimo DNS information was found."

    flushDNSCache
    
    if ${ARG_RESET_PRIMARY_INTERFACE_ON_DISCONNECT} ; then
        resetPrimaryInterface
    fi
    logMessage "End of output from ${OUR_NAME}"
    logMessage "**********************************************"
    exit 0
fi

# Get info saved by the up script
SHIMO_CONFIG="$( scutil <<-EOF
    open
    show State:/Network/OpenVPN
    quit
EOF
)"

PSID="$(echo "${SHIMO_CONFIG}" | grep -i '^[[:space:]]*Service :' | sed -e 's/^.*: //g')"
# Don't need: ARG_RESTORE_ON_DNS_RESET="$(echo "${SHIMO_CONFIG}" | grep -i '^[[:space:]]*RestoreOnDNSReset :' | sed -e 's/^.*: //g')"
# Don't need: ARG_RESTORE_ON_WINS_RESET="$(echo "${SHIMO_CONFIG}" | grep -i '^[[:space:]]*RestoreOnWINSReset :' | sed -e 's/^.*: //g')"
# Don't need: PROCESS="$(echo "${SHIMO_CONFIG}" | grep -i '^[[:space:]]*PID :' | sed -e 's/^.*: //g')"
# Don't need: ARG_IGNORE_OPTION_FLAGS="$(echo "${SHIMO_CONFIG}" | grep -i '^[[:space:]]*IgnoreOptionFlags :' | sed -e 's/^.*: //g')"
ARG_TAP="$(echo "${SHIMO_CONFIG}" | grep -i '^[[:space:]]*IsTapInterface :' | sed -e 's/^.*: //g')"
ARG_FLUSH_DNS_CACHE="$(echo "${SHIMO_CONFIG}" | grep -i '^[[:space:]]*FlushDNSCache :' | sed -e 's/^.*: //g')"
ARG_RESET_PRIMARY_INTERFACE_ON_DISCONNECT="$(echo "${SHIMO_CONFIG}" | grep -i '^[[:space:]]*ResetPrimaryInterface :' | sed -e 's/^.*: //g')"
bRouteGatewayIsDhcp="$(echo "${SHIMO_CONFIG}" | grep -i '^[[:space:]]*RouteGatewayIsDhcp :' | sed -e 's/^.*: //g')"
bTapDeviceHasBeenSetNone="$(echo "${SHIMO_CONFIG}" | grep -i '^[[:space:]]*TapDeviceHasBeenSetNone :' | sed -e 's/^.*: //g')"
bAlsoUsingSetupKeys="$(echo "${SHIMO_CONFIG}" | grep -i '^[[:space:]]*bAlsoUsingSetupKeys :' | sed -e 's/^.*: //g')"
sTunnelDevice="$(echo "${SHIMO_CONFIG}" | grep -i '^[[:space:]]*TunnelDevice :' | sed -e 's/^.*: //g')"

# Note: '\n' was translated into '\t', so we translate it back (it was done because grep and sed only work with single lines)
sRestoreIpv6Services="$(echo "${SHIMO_CONFIG}" | grep -i '^[[:space:]]*RestoreIpv6Services :' | sed -e 's/^.*: //g' | tr '\t' '\n')"

if ${ARG_TAP} ; then
    if [ "$bRouteGatewayIsDhcp" == "true" ]; then
        if [ "$bTapDeviceHasBeenSetNone" == "false" ]; then
            if [ -z "$dev" ]; then
                # If $dev is not defined, then use TunnelDevice, which was set from $dev by openvpn-up.sh
                if [ -n "${sTunnelDevice}" ]; then
                    logMessage "WARNING: \$dev not defined; using TunnelDevice: ${sTunnelDevice}"
                    set +e
                    ipconfig set "${sTunnelDevice}" NONE 2>/dev/null
                    set -e
                    logMessage "Released the DHCP lease via ipconfig set ${sTunnelDevice} NONE."
            else
                    logMessage "WARNING: Cannot configure TAP interface to NONE without \$dev or State:/Network/OpenVPN/TunnelDevice being defined. Device may not have disconnected properly."
                fi
            else
                set +e
                ipconfig set "$dev" NONE 2>/dev/null
                set -e
                logMessage "Released the DHCP lease via ipconfig set $dev NONE."
            fi
        fi
    fi
fi

# Issue warning if the primary service ID has changed
set +e # "grep" will return error status (1) if no matches are found, so don't fail if not found
PSID_CURRENT="$( scutil <<-EOF |
    open
    show State:/Network/OpenVPN
    quit
EOF
grep 'Service : ' | sed -e 's/.*Service : //'
)"
set -e # resume abort on error
if [ "${PSID}" != "${PSID_CURRENT}" ] ; then
    logMessage "Ignoring change of Network Primary Service from ${PSID} to ${PSID_CURRENT}"
fi

# Restore configurations
DNS_OLD="$( scutil <<-EOF
    open
    show State:/Network/OpenVPN/OldDNS
    quit
EOF
)"
SMB_OLD="$( scutil <<-EOF
    open
    show State:/Network/OpenVPN/OldSMB
    quit
EOF
)"
DNS_OLD_SETUP="$( scutil <<-EOF
    open
    show State:/Network/OpenVPN/OldDNSSetup
    quit
EOF
)"
CS_NO_SUCH_KEY="<dictionary> {
    ShimoNoSuchKey : true
}"

if [ "${DNS_OLD}" = "${CS_NO_SUCH_KEY}" ] ; then
    scutil <<-EOF
        open
        remove State:/Network/Service/${PSID}/DNS
        quit
EOF
else
    scutil <<-EOF
        open
        get State:/Network/OpenVPN/OldDNS
        set State:/Network/Service/${PSID}/DNS
        quit
EOF
fi

if [ "${DNS_OLD_SETUP}" = "${CS_NO_SUCH_KEY}" ] ; then
    if ${bAlsoUsingSetupKeys} ; then
        logDebugMessage "DEBUG: Removing 'Setup:' DNS key"
        scutil <<-EOF
            open
            remove Setup:/Network/Service/${PSID}/DNS
            quit
EOF
    else
        logDebugMessage "DEBUG: Not removing 'Setup:' DNS key"
    fi
else
    if ${bAlsoUsingSetupKeys} ; then
        logDebugMessage "DEBUG: Restoring 'Setup:' DNS key"
        scutil <<-EOF
            open
            get State:/Network/OpenVPN/OldDNSSetup
            set Setup:/Network/Service/${PSID}/DNS
            quit
EOF
    else
        logDebugMessage "DEBUG: Not restoring 'Setup:' DNS key"
    fi
fi

if [ "${SMB_OLD}" = "${CS_NO_SUCH_KEY}" ] ; then
    scutil > /dev/null <<-EOF
        open
        remove State:/Network/Service/${PSID}/SMB
        quit
EOF
else
    scutil > /dev/null <<-EOF
        open
        get State:/Network/OpenVPN/OldSMB
        set State:/Network/Service/${PSID}/SMB
        quit
EOF
fi

logMessage "Restored the DNS and SMB configurations"

set +e # "grep" will return error status (1) if no matches are found, so don't fail if not found
new_resolver_contents="$( grep -v '#' < /etc/resolv.conf )"
set -e # resume abort on error
logDebugMessage "DEBUG:"
logDebugMessage "DEBUG: /etc/resolve = ${new_resolver_contents}"

set +e # scutil --dns will return error status in case dns is already down, so don't fail if no dns found
scutil_dns="$( scutil --dns)"
set -e # resume abort on error
logDebugMessage "DEBUG:"
logDebugMessage "DEBUG: scutil --dns = ${scutil_dns}"
logDebugMessage "DEBUG:"

restore_ipv6 "$sRestoreIpv6Services"

flushDNSCache

# Remove our system configuration data
scutil <<-EOF
    open
    remove State:/Network/OpenVPN/OldDNS
    remove State:/Network/OpenVPN/OldSMB
    remove State:/Network/OpenVPN/OldDNSSetup
    remove State:/Network/OpenVPN/DNS
    remove State:/Network/OpenVPN/SMB
    remove State:/Network/OpenVPN
    quit
EOF

if ${ARG_RESET_PRIMARY_INTERFACE_ON_DISCONNECT} ; then
    resetPrimaryInterface
fi

logMessage "End of output from ${OUR_NAME}"
logMessage "**********************************************"

exit 0